while True:
  user_inp=float(input("What is your mark?: "))
  if  100>=user_inp>=0:
    break
  else:
    print("Invalid Mark")
print("Thank You!")