first_num = int(input("What is the first integer?: "))
second_num = int(input("What is the second integer?: "))
print(f"The quotient of {first_num} and {second_num} is {first_num//second_num} with a remainder of {first_num%second_num}")