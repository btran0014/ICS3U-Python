def c_to_f(c_inp):
    print (c_inp*9/5 + 32)

c_to_f(10)
c_to_f(20)
c_to_f(30)
c_to_f(121)
c_to_f(1234)